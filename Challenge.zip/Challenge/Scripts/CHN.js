 let currentPage = 0;

        const pages = [
            {
                title: "História e Sociedade",
                text: "Estudei os principais eventos históricos do Brasil e do mundo, compreendendo como o passado moldou nossa sociedade atual. Analisei revoluções, movimentos sociais, regimes políticos e transformações culturais que marcaram diferentes épocas, desenvolvendo pensamento crítico sobre questões sociais e políticas contemporâneas."
            },
            {
                title: "Geografia e Meio Ambiente",
                text: "Aprendi sobre geopolítica, urbanização, globalização e questões ambientais. Estudei a formação dos espaços geográficos, os impactos da ação humana no meio ambiente e a importância do desenvolvimento sustentável. Compreendi as relações entre sociedade, economia e natureza em escala local e global."
            },
            {
                title: "Filosofia e Sociologia",
                text: "Explorei diferentes correntes filosóficas e teorias sociológicas que explicam o comportamento humano e a organização social. Estudei ética, política, existência, conhecimento e as estruturas sociais que moldam nossa vida em sociedade. Desenvolvi capacidade de análise crítica e reflexão sobre questões fundamentais da existência humana."
            }
        ];

        function changePage(direction) {
            currentPage += direction;
            
            if (currentPage < 0) {
                currentPage = pages.length - 1;
            } else if (currentPage >= pages.length) {
                currentPage = 0;
            }
            
            updateContent();
        }

        function updateContent() {
            const content = document.getElementById('tabContent');
            const title = document.getElementById('tabTitle');
            const text = document.getElementById('tabText');
            
            content.classList.remove('fade-in');
            
            setTimeout(() => {
                title.textContent = pages[currentPage].title;
                text.textContent = pages[currentPage].text;
                content.classList.add('fade-in');
            }, 100);
            
            document.querySelectorAll('.page-dot').forEach((dot, index) => {
                if (index === currentPage) {
                    dot.classList.add('active');
                } else {
                    dot.classList.remove('active');
                }
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.page-dot').forEach((dot, index) => {
                dot.addEventListener('click', () => {
                    currentPage = index;
                    updateContent();
                });
            });
        });