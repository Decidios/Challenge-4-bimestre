 let currentPage = 0;

        const pages = [
            {
                title: "Álgebra e Equações",
                text: "Estudei profundamente os conceitos de álgebra, incluindo equações de primeiro e segundo grau, sistemas lineares e funções. Desenvolvi habilidades em resolver problemas complexos e aplicar esses conhecimentos em situações práticas do dia a dia."
            },
            {
                title: "Geometria Analítica",
                text: "Aprendi sobre pontos, retas, circunferências e cônicas no plano cartesiano. A geometria analítica me permitiu visualizar problemas matemáticos de forma gráfica e desenvolver o raciocínio espacial."
            },
            {
                title: "Trigonometria",
                text: "Domínio das razões trigonométricas, funções trigonométricas e suas aplicações. A trigonometria é fundamental para resolver problemas envolvendo ângulos, ondas e fenômenos periódicos."
            },
            {
                title: "Estatística e Probabilidade",
                text: "Estudei análise de dados, medidas de tendência central, gráficos estatísticos e cálculo de probabilidades. Esses conhecimentos são essenciais para interpretar informações e tomar decisões baseadas em dados."
            },
            {
                title: "Matemática Financeira",
                text: "Aprendi sobre juros simples e compostos, porcentagens, descontos e análise de investimentos. A matemática financeira é crucial para o planejamento e gestão de recursos no mundo atual."
            }
        ];

        function changePage(direction) {
            currentPage += direction;
            
            if (currentPage < 0) {
                currentPage = pages.length - 1;
            } else if (currentPage >= pages.length) {
                currentPage = 0;
            }
            
            updateContent();
        }

        function updateContent() {
            const content = document.getElementById('tabContent');
            const title = document.getElementById('tabTitle');
            const text = document.getElementById('tabText');
            
            content.classList.remove('fade-in');
            
            setTimeout(() => {
                title.textContent = pages[currentPage].title;
                text.textContent = pages[currentPage].text;
                content.classList.add('fade-in');
            }, 100);
            
            document.querySelectorAll('.page-dot').forEach((dot, index) => {
                if (index === currentPage) {
                    dot.classList.add('active');
                } else {
                    dot.classList.remove('active');
                }
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.page-dot').forEach((dot, index) => {
                dot.addEventListener('click', () => {
                    currentPage = index;
                    updateContent();
                });
            });
        });