  let currentPage = 0;

        const pages = [
            {
                title: "Literatura Brasileira",
                text: "Estudei os principais movimentos literários brasileiros, desde o Quinhentismo até o Modernismo. Analisei obras clássicas e contemporâneas, compreendendo o contexto histórico e social de cada período e desenvolvendo habilidades de interpretação crítica de textos literários."
            },
            {
                title: "Gramática e Redação",
                text: "Domínio das regras gramaticais da língua portuguesa, incluindo sintaxe, morfologia e semântica. Desenvolvi habilidades de produção textual, escrevendo textos dissertativos, narrativos e argumentativos com coesão e coerência."
            },
            {
                title: "Interpretação de Textos",
                text: "Aprimorei minha capacidade de compreender e analisar diferentes tipos de textos, identificando ideias principais, argumentos, figuras de linguagem e recursos estilísticos. Essencial para o desenvolvimento do pensamento crítico."
            },
            {
                title: "Língua Inglesa",
                text: "Estudei inglês com foco em leitura, escrita, conversação e compreensão auditiva. Desenvolvi vocabulário técnico e habilidades de comunicação em contextos acadêmicos e profissionais, preparando-me para um mercado globalizado."
            },
            {
                title: "Arte e Cultura",
                text: "Explorei diferentes manifestações artísticas e culturais, analisando obras de arte, cinema, música e teatro. Compreendi como a arte reflete e influencia a sociedade, desenvolvendo senso estético e pensamento crítico."
            }
        ];

        function changePage(direction) {
            currentPage += direction;
            
            if (currentPage < 0) {
                currentPage = pages.length - 1;
            } else if (currentPage >= pages.length) {
                currentPage = 0;
            }
            
            updateContent();
        }

        function updateContent() {
            const content = document.getElementById('tabContent');
            const title = document.getElementById('tabTitle');
            const text = document.getElementById('tabText');
            
            content.classList.remove('fade-in');
            
            setTimeout(() => {
                title.textContent = pages[currentPage].title;
                text.textContent = pages[currentPage].text;
                content.classList.add('fade-in');
            }, 100);
            
            document.querySelectorAll('.page-dot').forEach((dot, index) => {
                if (index === currentPage) {
                    dot.classList.add('active');
                } else {
                    dot.classList.remove('active');
                }
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.page-dot').forEach((dot, index) => {
                dot.addEventListener('click', () => {
                    currentPage = index;
                    updateContent();
                });
            });
        });