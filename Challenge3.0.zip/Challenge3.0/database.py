import sqlite3
import os

def criar_banco():
    """Cria o banco de dados e tabela de contatos"""
    try:
        # Conectar ao banco (cria se não existir)
        conn = sqlite3.connect('contatos_portfolio.db')
        cursor = conn.cursor()
        
        # Criar tabela de mensagens
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS mensagens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL,
            assunto TEXT NOT NULL,
            mensagem TEXT NOT NULL,
            data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Verificar se já existe a mensagem de teste
        cursor.execute("SELECT COUNT(*) FROM mensagens WHERE nome = 'Teste'")
        existe_teste = cursor.fetchone()[0]
        
        # Adicionar mensagem de teste apenas se não existir
        if existe_teste == 0:
            cursor.execute('''
            INSERT INTO mensagens (nome, email, assunto, mensagem)
            VALUES (?, ?, ?, ?)
            ''', (
                "Teste", 
                "teste@email.com", 
                "Mensagem de Teste Automática",
                "Esta é uma mensagem de teste gerada automaticamente quando o banco foi criado!"
            ))
            print("✅ Mensagem de teste adicionada!")
        
        conn.commit()
        conn.close()
        
        print("✅ Banco de dados 'contatos_portfolio.db' criado com sucesso!")
        return True
        
    except Exception as e:
        print(f"❌ Erro ao criar banco: {e}")
        return False

def salvar_mensagem(nome, email, assunto, mensagem):
    """Salva uma nova mensagem no banco"""
    try:
        conn = sqlite3.connect('contatos_portfolio.db')
        cursor = conn.cursor()
        
        cursor.execute('''
        INSERT INTO mensagens (nome, email, assunto, mensagem)
        VALUES (?, ?, ?, ?)
        ''', (nome, email, assunto, mensagem))
        
        conn.commit()
        conn.close()
        
        print(f"✅ Mensagem de '{nome}' salva no banco!")
        print(f"   📧 Email: {email}")
        print(f"   📝 Assunto: {assunto}")
        print(f"   💬 Mensagem: {mensagem[:50]}...")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro ao salvar mensagem: {e}")
        return False

def listar_mensagens():
    """Lista todas as mensagens do banco"""
    try:
        conn = sqlite3.connect('contatos_portfolio.db')
        cursor = conn.cursor()
        
        cursor.execute('''
        SELECT id, nome, email, assunto, mensagem, data_envio 
        FROM mensagens 
        ORDER BY data_envio DESC
        ''')
        
        mensagens = cursor.fetchall()
        conn.close()
        
        return mensagens
        
    except Exception as e:
        print(f"❌ Erro ao listar mensagens: {e}")
        return []

def contar_mensagens():
    """Conta quantas mensagens existem no banco"""
    try:
        conn = sqlite3.connect('contatos_portfolio.db')
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM mensagens")
        count = cursor.fetchone()[0]
        
        conn.close()
        return count
        
    except Exception as e:
        print(f"❌ Erro ao contar mensagens: {e}")
        return 0

# Teste do banco quando executado diretamente
if __name__ == "__main__":
    print("🔄 Iniciando banco de dados...")
    
    if criar_banco():
        mensagens = listar_mensagens()
        total = contar_mensagens()
        
        print(f"🎉 Banco pronto! Total de mensagens: {total}")
        
        if mensagens:
            print("\n📨 Mensagens no banco:")
            for msg in mensagens:
                print(f"   👤 {msg[1]} - {msg[3]}")
                
        print("\n🚀 Agora execute: python app.py")
        
    else:
        print("😥 Falha ao criar o banco")