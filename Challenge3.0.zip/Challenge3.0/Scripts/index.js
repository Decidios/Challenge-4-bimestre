 // Animação de scroll para navbar
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('navbar-scrolled');
            } else {
                navbar.classList.remove('navbar-scrolled');
            }
        });

        // Animação de entrada para elementos
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, observerOptions);

        document.querySelectorAll('.fade-in').forEach(element => {
            observer.observe(element);
        });

        // Criar partículas flutuantes
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const particleCount = 15;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                // Tamanho e posição aleatórios
                const size = Math.random() * 8 + 2;
                const left = Math.random() * 100;
                const top = Math.random() * 100;
                const delay = Math.random() * 5;
                
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.left = `${left}%`;
                particle.style.top = `${top}%`;
                particle.style.animationDelay = `${delay}s`;
                
                particlesContainer.appendChild(particle);
            }
        }

        // Função para enviar email (simulação)
        function sendEmail(event) {
            event.preventDefault();
            
            const form = document.getElementById('contactForm');
            const formMessage = document.getElementById('formMessage');
            
            // Simular envio de email
            setTimeout(() => {
                form.reset();
                formMessage.style.display = 'block';
                
                // Esconder mensagem após 5 segundos
                setTimeout(() => {
                    formMessage.style.display = 'none';
                }, 5000);
            }, 1000);
        }

        // Inicializar partículas quando a página carregar
        window.addEventListener('load', createParticles);
        function sendEmail(event) {
    event.preventDefault();
    
    const form = document.getElementById('contactForm');
    const formMessage = document.getElementById('formMessage');
    const submitBtn = form.querySelector('button[type="submit"]');
    
    // Pegar dados do formulário
    const formData = {
        nome: document.getElementById('name').value,
        email: document.getElementById('email').value,
        assunto: document.getElementById('subject').value,
        mensagem: document.getElementById('message').value
    };
    
    // Validar campos
    if (!formData.nome || !formData.email || !formData.assunto || !formData.mensagem) {
        formMessage.className = 'alert alert-danger mt-3 text-center';
        formMessage.textContent = 'Por favor, preencha todos os campos!';
        formMessage.style.display = 'block';
        return;
    }
    
    // Mostrar loading no botão
    submitBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Enviando...';
    submitBtn.disabled = true;
    
    console.log('📤 Enviando dados:', formData);
    
    // Enviar para o servidor Flask
    fetch('/enviar-mensagem', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erro na rede');
        }
        return response.json();
    })
    .then(data => {
        console.log('✅ Resposta do servidor:', data);
        
        if (data.success) {
            // Sucesso
            formMessage.className = 'alert alert-success mt-3 text-center';
            formMessage.textContent = data.message;
            formMessage.style.display = 'block';
            form.reset();
        } else {
            // Erro
            formMessage.className = 'alert alert-danger mt-3 text-center';
            formMessage.textContent = data.message;
            formMessage.style.display = 'block';
        }
    })
    .catch(error => {
        console.error('❌ Erro:', error);
        // Erro de conexão
        formMessage.className = 'alert alert-danger mt-3 text-center';
        formMessage.textContent = 'Erro de conexão. Verifique se o servidor está rodando!';
        formMessage.style.display = 'block';
    })
    .finally(() => {
        // Restaurar botão
        submitBtn.innerHTML = '<i class="bi bi-send me-2"></i>Enviar Mensagem';
        submitBtn.disabled = false;
        
        // Esconder mensagem após 5 segundos
        setTimeout(() => {
            formMessage.style.display = 'none';
        }, 5000);
    });
}