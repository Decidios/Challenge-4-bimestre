// Função para enviar mensagem para o banco de dados
function sendEmail(event) {
    event.preventDefault();
    
    const form = document.getElementById('contactForm');
    const formMessage = document.getElementById('formMessage');
    const submitBtn = form.querySelector('button[type="submit"]');
    
    // Pegar dados do formulário
    const formData = {
        nome: document.getElementById('name').value,
        email: document.getElementById('email').value,
        assunto: document.getElementById('subject').value,
        mensagem: document.getElementById('message').value
    };
    
    // Validar campos
    if (!formData.nome || !formData.email || !formData.assunto || !formData.mensagem) {
        formMessage.className = 'alert alert-danger mt-3 text-center';
        formMessage.textContent = 'Por favor, preencha todos os campos!';
        formMessage.style.display = 'block';
        return;
    }
    
    // Mostrar loading no botão
    submitBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Enviando...';
    submitBtn.disabled = true;
    
    console.log('📤 Enviando dados:', formData);
    
    // Enviar para o servidor Flask
    fetch('/enviar-mensagem', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erro na rede');
        }
        return response.json();
    })
    .then(data => {
        console.log('✅ Resposta do servidor:', data);
        
        if (data.success) {
            // Sucesso
            formMessage.className = 'alert alert-success mt-3 text-center';
            formMessage.textContent = data.message;
            formMessage.style.display = 'block';
            form.reset();
        } else {
            // Erro
            formMessage.className = 'alert alert-danger mt-3 text-center';
            formMessage.textContent = data.message;
            formMessage.style.display = 'block';
        }
    })
    .catch(error => {
        console.error('❌ Erro:', error);
        // Erro de conexão
        formMessage.className = 'alert alert-danger mt-3 text-center';
        formMessage.textContent = 'Erro de conexão. Verifique se o servidor está rodando!';
        formMessage.style.display = 'block';
    })
    .finally(() => {
        // Restaurar botão
        submitBtn.innerHTML = '<i class="bi bi-send me-2"></i>Enviar Mensagem';
        submitBtn.disabled = false;
        
        // Esconder mensagem após 5 segundos
        setTimeout(() => {
            formMessage.style.display = 'none';
        }, 5000);
    });
}