from flask import Flask, request, jsonify, send_from_directory
import database
import os

app = Flask(__name__)

# Servir arquivos estáticos (CSS, JS, imagens)
@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('.', path)

# Rota principal - servir o index.html
@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/enviar-mensagem', methods=['POST'])
def enviar_mensagem():
    try:
        # Pegar dados do formulário
        data = request.get_json()
        nome = data.get('nome')
        email = data.get('email')
        assunto = data.get('assunto')
        mensagem = data.get('mensagem')
        
        print(f"📨 Recebendo mensagem de: {nome} ({email})")
        
        # Validar dados
        if not all([nome, email, assunto, mensagem]):
            return jsonify({'success': False, 'message': 'Todos os campos são obrigatórios!'})
        
        # Salvar no banco
        if database.salvar_mensagem(nome, email, assunto, mensagem):
            return jsonify({
                'success': True, 
                'message': 'Mensagem enviada com sucesso! Entrarei em contato em breve.'
            })
        else:
            return jsonify({
                'success': False, 
                'message': 'Erro ao enviar mensagem. Tente novamente.'
            })
            
    except Exception as e:
        print(f"❌ Erro no servidor: {e}")
        return jsonify({
            'success': False, 
            'message': 'Erro interno do servidor.'
        })

@app.route('/admin/mensagens')
def admin_mensagens():
    """Página para ver todas as mensagens"""
    mensagens = database.listar_mensagens()
    print(f"📊 Carregando {len(mensagens)} mensagens")
    return send_from_directory('templates', 'admin_mensagens.html')

if __name__ == '__main__':
    # Verificar se o banco existe, se não, criar
    if not os.path.exists('contatos_portfolio.db'):
        print("🔄 Criando banco de dados...")
        database.criar_banco()
    
    print("🚀 Servidor Flask iniciando...")
    print("📧 Sistema de contatos pronto!")
    print("🌐 Acesse: http://localhost:5000")
    app.run(debug=True, port=5000)