let currentPage = 0;

const pages = [
    {
        title: "Funções",
        text: "Estudei mecânica, termodinâmica, eletromagnetismo, ondulatória e física moderna. Compreendi as leis fundamentais que governam o universo físico, desde o movimento dos corpos até fenômenos quânticos. Desenvolvi habilidades em resolver problemas práticos aplicando conceitos físicos e utilizando fórmulas matemáticas para descrever fenômenos naturais."
    },
    {
        title: "Análise combinatória",
        text: "Aprendi sobre química orgânica, inorgânica, físico-química e bioquímica. Estudei a estrutura da matéria, reações químicas, estequiometria, termoquímica e equilíbrio químico. Compreendi como as substâncias interagem, se transformam e como a química está presente em processos industriais, ambientais e biológicos do nosso cotidiano."
    },
    {
        title: "Estatistica",
        text: "Explorei citologia, genética, evolução, ecologia, anatomia e fisiologia humana. Estudei desde estruturas microscópicas como células e DNA até ecossistemas complexos. Compreendi os processos da vida, a biodiversidade, os mecanismos de hereditariedade e a importância da preservação ambiental para a sustentabilidade do planeta."
    }
];

function changePage(direction) {
    currentPage += direction;
    
    if (currentPage < 0) {
        currentPage = pages.length - 1;
    } else if (currentPage >= pages.length) {
        currentPage = 0;
    }
    
    updateContent();
}

function updateContent() {
    const content = document.getElementById('tabContent');
    const title = document.getElementById('tabTitle');
    const text = document.getElementById('tabText');
    
    content.classList.remove('fade-in');
    
    setTimeout(() => {
        title.textContent = pages[currentPage].title;
        text.textContent = pages[currentPage].text;
        content.classList.add('fade-in');
    }, 100);
    
    document.querySelectorAll('.page-dot').forEach((dot, index) => {
        if (index === currentPage) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.page-dot').forEach((dot, index) => {
        dot.addEventListener('click', () => {
            currentPage = index;
            updateContent();
        });
    });
});