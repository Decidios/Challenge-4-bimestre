import database

print("🔍 MENSAGENS RECEBIDAS")
print("=" * 60)

mensagens = database.listar_mensagens()

if not mensagens:
    print("📭 Nenhuma mensagem encontrada!")
    print("💡 Envie uma mensagem pelo formulário primeiro!")
else:
    print(f"📊 Total de mensagens: {len(mensagens)}")
    print("=" * 60)
    
    for i, msg in enumerate(mensagens, 1):
        print(f"""
📨 Mensagem #{i}
👤 Nome: {msg[1]}
📧 Email: {msg[2]}
📝 Assunto: {msg[3]}
💬 Mensagem: {msg[4]}
📅 Data: {msg[5]}
{'─' * 60}""")

input("\n🎯 Pressione Enter para voltar...")