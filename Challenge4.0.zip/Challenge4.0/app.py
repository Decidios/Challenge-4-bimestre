from flask import Flask, request, jsonify, send_from_directory
import sqlite3
import os
import json

app = Flask(__name__)

# Servir TODOS os arquivos estáticos
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_static(path):
    if path == "":
        return send_from_directory('.', 'index.html')
    else:
        return send_from_directory('.', path)


@app.route('/enviar-mensagem', methods=['POST'])
def enviar_mensagem():
    try:
        print(" MENSAGEM RECEBIDA!")
        
        
        if request.content_type == 'application/json':
            data = request.get_json()
        else:
           
            raw_data = request.get_data()
            try:
                data_str = raw_data.decode('utf-8')
                data = json.loads(data_str)
            except UnicodeDecodeError:
                
                data_str = raw_data.decode('latin-1')
                data = json.loads(data_str)
            except Exception as e:
                print(f"❌ Erro ao decodificar: {e}")
                return jsonify({'success': False, 'message': 'Erro ao processar dados'})
        
        print(f"📝 Dados recebidos: {data}")
        
        nome = data.get('nome', '')
        email = data.get('email', '')
        assunto = data.get('assunto', '')
        mensagem = data.get('mensagem', '')
        
        if not all([nome, email, assunto, mensagem]):
            return jsonify({'success': False, 'message': 'Preencha todos os campos!'})
        
        # Salvar no banco
        conn = sqlite3.connect('contatos_portfolio.db')
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO mensagens (nome, email, assunto, mensagem) VALUES (?, ?, ?, ?)",
            (nome, email, assunto, mensagem)
        )
        conn.commit()
        conn.close()
        
        print(f"✅ SALVO NO BANCO: {nome} - {email}")
        return jsonify({'success': True, 'message': 'Mensagem enviada com sucesso! 🎉'})
        
    except Exception as e:
        print(f"❌ ERRO: {e}")
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

@app.route('/admin/mensagens')
def admin_mensagens():
    return send_from_directory('.', 'templates/admin_mensagens.html')

if __name__ == '__main__':
    print("🚀 SERVIDOR FLASK RODANDO NA PORTA 5000")
    print("🌐 ACESSE: http://localhost:5000")
    app.run(debug=True, port=5000)