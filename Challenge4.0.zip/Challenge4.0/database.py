import sqlite3
import os

def criar_banco():
    """Cria o banco de dados e tabela de contatos"""
    try:
        conn = sqlite3.connect('contatos_portfolio.db')
        cursor = conn.cursor()
        
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS mensagens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL,
            assunto TEXT NOT NULL,
            mensagem TEXT NOT NULL,
            data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        conn.commit()
        conn.close()
        print("✅ Banco de dados 'contatos_portfolio.db' criado com sucesso!")
        return True
    except Exception as e:
        print(f"❌ Erro ao criar banco: {e}")
        return False

def salvar_mensagem(nome, email, assunto, mensagem):
    """Salva uma nova mensagem no banco"""
    try:
        conn = sqlite3.connect('contatos_portfolio.db')
        cursor = conn.cursor()
        
        cursor.execute('''
        INSERT INTO mensagens (nome, email, assunto, mensagem)
        VALUES (?, ?, ?, ?)
        ''', (nome, email, assunto, mensagem))
        
        conn.commit()
        conn.close()
        print(f"✅ Mensagem de {nome} salva no banco!")
        return True
    except Exception as e:
        print(f"❌ Erro ao salvar mensagem: {e}")
        return False

def listar_mensagens():
    """Lista todas as mensagens"""
    try:
        conn = sqlite3.connect('contatos_portfolio.db')
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM mensagens ORDER BY data_envio DESC')
        mensagens = cursor.fetchall()
        
        conn.close()
        return mensagens
    except Exception as e:
        print(f"❌ Erro ao listar mensagens: {e}")
        return []

if __name__ == "__main__":
    criar_banco()