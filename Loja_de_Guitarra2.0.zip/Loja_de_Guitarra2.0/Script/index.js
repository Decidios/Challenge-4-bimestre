    lucide.createIcons();

    let cart = [];
    let cartOpen = false;
    let selectedPayment = null;
    let currentProfileTab = 'info';

  const products = [
  { 
    name: 'Stratocaster Classic', 
    price: 4500, 
    type: 'Elétrica', 
    description: 'Guitarra elétrica clássica com som versátil',
    image: 'https://images.unsplash.com/photo-1558098329-a11cff621064?w=600&h=400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1558098329-a11cff621064?w=150&h=150&fit=crop'
  },
  { 
    name: 'Les Paul Standard', 
    price: 6800, 
    type: 'Elétrica', 
    description: 'Som encorpado ideal para rock',
    image: 'https://images.unsplash.com/photo-1564186763535-ebb21c52731d?w=600&h=400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1564186763535-ebb21c52731d?w=150&h=150&fit=crop'
  },
  { 
    name: 'Telecaster Vintage', 
    price: 5200, 
    type: 'Elétrica', 
    description: 'Timbre brilhante e definido',
    image: 'https://images.unsplash.com/photo-1606112219348-204da240c7c4?w=600&h=400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1606112219348-204da240c7c4?w=150&h=150&fit=crop'
  },
  { 
    name: 'SG Special', 
    price: 3900, 
    type: 'Elétrica', 
    description: 'Leve e poderosa para rock pesado',
    image: 'https://images.unsplash.com/photo-1570586437263-ab629fccc6c1?w=600&h=400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1570586437263-ab629fccc6c1?w=150&h=150&fit=crop'
  },
  { 
    name: 'Acústica Dreadnought', 
    price: 2800, 
    type: 'Acústica', 
    description: 'Som rico e projeção potente',
    image: 'https://images.unsplash.com/photo-1525202015756-1ba56c98288b?w=600&h=400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1525202015756-1ba56c98288b?w=150&h=150&fit=crop'
  },
  { 
    name: 'Classical Pro', 
    price: 3200, 
    type: 'Clássica', 
    description: 'Cordas de nylon para som suave',
    image: 'https://images.unsplash.com/photo-1598488031602-e3c5cb0b5ba2?w=600&h=400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1598488031602-e3c5cb0b5ba2?w=150&h=150&fit=crop'
  }
];

    function scrollToProducts() {
      document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
    }

    function toggleMobileMenu() {
      const menu = document.getElementById('mobile-menu');
      const overlay = document.getElementById('mobile-overlay');
      
      if (menu.classList.contains('open')) {
        menu.classList.remove('open');
        overlay.classList.add('hidden');
        document.body.style.overflow = 'auto';
      } else {
        menu.classList.add('open');
        overlay.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
      }
    }

    function openSearch() {
      const modal = document.getElementById('search-modal');
      const overlay = document.getElementById('search-overlay');
      const input = document.getElementById('search-input');
      
      modal.classList.remove('hidden');
      overlay.classList.remove('hidden');
      setTimeout(() => modal.classList.add('open'), 10);
      document.body.style.overflow = 'hidden';
      
      setTimeout(() => input.focus(), 300);
    }

    function closeSearch() {
      const modal = document.getElementById('search-modal');
      const overlay = document.getElementById('search-overlay');
      
      modal.classList.remove('open');
      overlay.classList.add('hidden');
      setTimeout(() => modal.classList.add('hidden'), 300);
      document.body.style.overflow = 'auto';
    }

    function performSearch() {
      const query = document.getElementById('search-input').value.toLowerCase();
      const resultsContainer = document.getElementById('search-results');
      
      if (query.length < 2) {
        resultsContainer.innerHTML = '<p class="text-gray-400 text-center py-8">Digite pelo menos 2 caracteres</p>';
        return;
      }
      
      const filteredProducts = products.filter(product => 
        product.name.toLowerCase().includes(query) ||
        product.type.toLowerCase().includes(query) ||
        product.description.toLowerCase().includes(query)
      );
      
      if (filteredProducts.length === 0) {
        resultsContainer.innerHTML = `
          <div class="text-center py-8">
            <i data-lucide="search-x" class="w-16 h-16 text-gray-500 mx-auto mb-4"></i>
            <p class="text-gray-400">Nenhum produto encontrado</p>
            <p class="text-gray-500 text-sm mt-2">Tente outros termos de busca</p>
          </div>
        `;
      } else {
        resultsContainer.innerHTML = filteredProducts.map(product => `
          <div class="flex items-center gap-4 p-4 hover:bg-white/5 rounded-lg cursor-pointer transition" onclick="showProductDetail('${product.name}'); closeSearch();">
            <img src="${product.thumb}" alt="${product.name}" class="w-12 h-12 object-cover rounded-lg">
            <div class="flex-1">
              <h4 class="text-white font-semibold">${product.name}</h4>
              <p class="text-gray-400 text-sm">${product.type} • ${product.description}</p>
              <p class="text-purple-400 font-bold mt-1">R$ ${product.price.toLocaleString('pt-BR')}</p>
            </div>
            <i data-lucide="chevron-right" class="w-5 h-5 text-gray-400"></i>
          </div>
        `).join('');
      }
      
      lucide.createIcons();
    }

    function showGuitarDetails(model) {
      const product = products.find(p => p.name.toLowerCase().includes(model));
      if (product) {
        showProductDetail(product.name);
      }
    }

    function showProductDetail(productName) {
      const product = products.find(p => p.name === productName);
      if (!product) return;
      
      const modal = document.getElementById('product-modal');
      const overlay = document.getElementById('product-overlay');
      const title = document.getElementById('product-modal-title');
      const content = document.getElementById('product-modal-content');
      
      title.textContent = product.name;
      content.innerHTML = `
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div class="rounded-2xl h-80 overflow-hidden">
            <img src="${product.image}" alt="${product.name}" class="w-full h-full object-cover guitar-image">
          </div>
          <div class="space-y-6">
            <div>
              <span class="inline-block bg-purple-500/20 text-purple-400 px-3 py-1 rounded-full text-sm mb-2">
                ${product.type}
              </span>
              <h3 class="text-2xl font-bold text-white mb-4">${product.name}</h3>
              <p class="text-gray-300 leading-relaxed">${product.description}</p>
            </div>
            
            <div class="space-y-4">
              <div class="specs-item bg-white/5 rounded-lg p-4 border border-purple-500/20">
                <h4 class="text-white font-semibold mb-2 flex items-center gap-2">
                  <i data-lucide="star" class="w-4 h-4 text-yellow-400"></i>
                  Características
                </h4>
                <ul class="text-gray-300 text-sm space-y-1">
                  <li>• Corpo sólido em mogno</li>
                  <li>• Captadores humbucker</li>
                  <li>• Braço em maple</li>
                  <li>• Escala em rosewood</li>
                </ul>
              </div>
              
              <div class="specs-item bg-white/5 rounded-lg p-4 border border-purple-500/20">
                <h4 class="text-white font-semibold mb-2 flex items-center gap-2">
                  <i data-lucide="package" class="w-4 h-4 text-blue-400"></i>
                  Inclui
                </h4>
                <ul class="text-gray-300 text-sm space-y-1">
                  <li>• Guitarra principal</li>
                  <li>• Case rígido</li>
                  <li>• Cordas extras</li>
                  <li>• Correia de couro</li>
                </ul>
              </div>
            </div>
            
            <div class="flex items-center justify-between pt-4 border-t border-gray-700">
              <div>
                <span class="text-3xl font-bold text-purple-400">
                  R$ ${product.price.toLocaleString('pt-BR')}
                </span>
                <p class="text-gray-400 text-sm">ou 12x sem juros</p>
              </div>
              <button onclick="addToCart('${product.name}', ${product.price}, '${product.emoji}', '${product.thumb}'); closeProductModal();" 
                      class="btn-primary text-white px-6 py-3 rounded-lg font-semibold flex items-center gap-2">
                <i data-lucide="shopping-cart" class="w-4 h-4"></i>
                Adicionar ao Carrinho
              </button>
            </div>
          </div>
        </div>
      `;
      
      modal.classList.remove('hidden');
      overlay.classList.remove('hidden');
      setTimeout(() => modal.classList.add('open'), 10);
      document.body.style.overflow = 'hidden';
      
      lucide.createIcons();
    }

    function closeProductModal() {
      const modal = document.getElementById('product-modal');
      const overlay = document.getElementById('product-overlay');
      
      modal.classList.remove('open');
      overlay.classList.add('hidden');
      setTimeout(() => modal.classList.add('hidden'), 300);
      document.body.style.overflow = 'auto';
    }

    function openProfile() {
      const modal = document.getElementById('profile-modal');
      const overlay = document.getElementById('profile-overlay');
      
      modal.classList.remove('hidden');
      overlay.classList.remove('hidden');
      setTimeout(() => modal.classList.add('open'), 10);
      document.body.style.overflow = 'hidden';
    }

    function closeProfile() {
      const modal = document.getElementById('profile-modal');
      const overlay = document.getElementById('profile-overlay');
      
      modal.classList.remove('open');
      overlay.classList.add('hidden');
      setTimeout(() => modal.classList.add('hidden'), 300);
      document.body.style.overflow = 'auto';
    }

    function switchProfileTab(tabName) {
      currentProfileTab = tabName;
      
      document.querySelectorAll('.profile-tab').forEach(tab => {
        tab.classList.remove('active');
      });
      
     
      event.target.classList.add('active');
      
      
      document.querySelectorAll('.profile-content').forEach(content => {
        content.classList.add('hidden');
      });
      
       
      document.getElementById(`profile-${tabName}`).classList.remove('hidden');
    }

    function addToCart(productName, price, emoji, image) {
      const existingItem = cart.find(item => item.name === productName);
      
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        cart.push({
          name: productName,
          price: price,
          emoji: emoji,
          image: image,
          quantity: 1,
          id: Date.now()
        });
      }
      
      updateCartUI();
      showNotification();
      
      if (!cartOpen) {
        toggleCart();
      }
    }

    function removeFromCart(itemId) {
      cart = cart.filter(item => item.id !== itemId);
      updateCartUI();
    }

    function updateQuantity(itemId, change) {
      const item = cart.find(item => item.id === itemId);
      if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
          removeFromCart(itemId);
        } else {
          updateCartUI();
        }
      }
    }

    function updateCartUI() {
      const cartItems = document.getElementById('cart-items');
      const cartCount = document.getElementById('cart-count');
      const cartSubtotal = document.getElementById('cart-subtotal');
      const cartTotal = document.getElementById('cart-total');
      const emptyCartMessage = document.getElementById('empty-cart-message');

      const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
      cartCount.textContent = totalItems;

      if (cart.length === 0) {
        emptyCartMessage.classList.remove('hidden');
        cartItems.innerHTML = '';
      } else {
        emptyCartMessage.classList.add('hidden');
        
        cartItems.innerHTML = cart.map(item => `
          <div class="checkout-item bg-white/5 rounded-lg p-4 border border-purple-500/20">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-3">
                <img src="${item.image}" alt="${item.name}" class="w-12 h-12 object-cover rounded-lg">
                <div>
                  <h4 class="text-white font-semibold">${item.name}</h4>
                  <p class="text-purple-400 font-bold">R$ ${item.price.toLocaleString('pt-BR')}</p>
                </div>
              </div>
              <button onclick="removeFromCart(${item.id})" class="text-red-400 hover:text-red-300 transition">
                <i data-lucide="trash-2" class="w-4 h-4"></i>
              </button>
            </div>
            <div class="flex items-center justify-between mt-3">
              <div class="flex items-center gap-2">
                <button onclick="updateQuantity(${item.id}, -1)" class="w-8 h-8 bg-white/10 rounded flex items-center justify-center text-white hover:bg-white/20 transition">
                  <i data-lucide="minus" class="w-3 h-3"></i>
                </button>
                <span class="text-white font-semibold w-8 text-center">${item.quantity}</span>
                <button onclick="updateQuantity(${item.id}, 1)" class="w-8 h-8 bg-white/10 rounded flex items-center justify-center text-white hover:bg-white/20 transition">
                  <i data-lucide="plus" class="w-3 h-3"></i>
                </button>
              </div>
              <span class="text-white font-bold">R$ ${(item.price * item.quantity).toLocaleString('pt-BR')}</span>
            </div>
          </div>
        `).join('');

        lucide.createIcons();
      }

      const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      cartSubtotal.textContent = `R$ ${subtotal.toLocaleString('pt-BR')}`;
      cartTotal.textContent = `R$ ${subtotal.toLocaleString('pt-BR')}`;
    }

    function showNotification() {
      const notification = document.getElementById('cart-notification');
      notification.classList.remove('hidden');
      
      setTimeout(() => {
        notification.classList.add('hidden');
      }, 3000);
    }

    function toggleCart() {
      const sidebar = document.getElementById('cart-sidebar');
      const overlay = document.getElementById('cart-overlay');
      
      cartOpen = !cartOpen;
      
      if (cartOpen) {
        sidebar.classList.add('open');
        overlay.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
      } else {
        sidebar.classList.remove('open');
        overlay.classList.add('hidden');
        document.body.style.overflow = 'auto';
      }
    }

    function openCheckout() {
      if (cart.length === 0) {
        alert('Seu carrinho está vazio!');
        return;
      }
      
      updateCheckoutUI();
      const modal = document.getElementById('checkout-modal');
      modal.classList.remove('hidden');
      setTimeout(() => modal.classList.add('open'), 10);
      document.body.style.overflow = 'hidden';
      toggleCart(); // Fecha o carrinho
    }

    function closeCheckout() {
      const modal = document.getElementById('checkout-modal');
      modal.classList.remove('open');
      setTimeout(() => modal.classList.add('hidden'), 300);
      document.body.style.overflow = 'auto';
      selectedPayment = null;
      resetPaymentSelection();
    }

    function selectPayment(method) {
      selectedPayment = method;
      

      resetPaymentSelection();
      

      const option = document.querySelector(`[onclick="selectPayment('${method}')"]`);
      const radio = option.querySelector('.payment-radio');
      const details = document.getElementById(`${method}-details`);
      
      option.classList.add('selected');
      radio.style.backgroundColor = '#8b5cf6';
      radio.style.borderColor = '#8b5cf6';
      details.classList.remove('hidden');
      

      const confirmBtn = document.getElementById('confirm-payment');
      confirmBtn.disabled = false;
      confirmBtn.classList.remove('opacity-50', 'cursor-not-allowed');
    }

    function resetPaymentSelection() {
      const options = document.querySelectorAll('.payment-option');
      options.forEach(option => {
        option.classList.remove('selected');
        const radio = option.querySelector('.payment-radio');
        radio.style.backgroundColor = '';
        radio.style.borderColor = '';
      });
      
      const details = document.querySelectorAll('[id$="-details"]');
      details.forEach(detail => detail.classList.add('hidden'));
    }

    function processPayment() {
      if (!selectedPayment) {
        alert('Por favor, selecione um método de pagamento!');
        return;
      }
      
      const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      
      const confirmBtn = document.getElementById('confirm-payment');
      confirmBtn.innerHTML = '<i data-lucide="loader" class="w-5 h-5 animate-spin"></i> Processando...';
      confirmBtn.disabled = true;
      
      setTimeout(() => {
        alert(`🎉 Pagamento realizado com sucesso!\nMétodo: ${selectedPayment.toUpperCase()}\nTotal: R$ ${total.toLocaleString('pt-BR')}\n\nObrigado pela compra!`);
        
       
        cart = [];
        updateCartUI();
        closeCheckout();
        
        
        confirmBtn.innerHTML = '<i data-lucide="lock" class="w-5 h-5"></i> Confirmar Pagamento';
        confirmBtn.disabled = true;
        confirmBtn.classList.add('opacity-50', 'cursor-not-allowed');
      }, 2000);
    }

    function updateCheckoutUI() {
      const checkoutItems = document.getElementById('checkout-items');
      const checkoutSubtotal = document.getElementById('checkout-subtotal');
      const checkoutTotal = document.getElementById('checkout-total');
      
      
      checkoutItems.innerHTML = cart.map(item => `
        <div class="flex items-center justify-between py-2 border-b border-gray-700/50">
          <div class="flex items-center gap-3">
            <img src="${item.image}" alt="${item.name}" class="w-10 h-10 object-cover rounded-lg">
            <div>
              <h4 class="text-white font-semibold text-sm">${item.name}</h4>
              <p class="text-gray-400 text-xs">Qtd: ${item.quantity}</p>
            </div>
          </div>
          <span class="text-purple-400 font-bold">R$ ${(item.price * item.quantity).toLocaleString('pt-BR')}</span>
        </div>
      `).join('');
      
      
      const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      checkoutSubtotal.textContent = `R$ ${subtotal.toLocaleString('pt-BR')}`;
      checkoutTotal.textContent = `R$ ${subtotal.toLocaleString('pt-BR')}`;
      
     
      const installmentsSelect = document.querySelector('#credit-details select');
      if (installmentsSelect) {
        installmentsSelect.innerHTML = '';
        for (let i = 1; i <= 12; i++) {
          const installmentValue = (subtotal / i).toLocaleString('pt-BR', { minimumFractionDigits: 2 });
          installmentsSelect.innerHTML += `<option value="${i}" class="bg-slate-900">${i}x de R$ ${installmentValue}</option>`;
        }
      }
    }

  
    function enviarMensagem() {
      alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
    }

    
    updateCartUI();
    
async function cadastrarCliente(nome, email, telefone = null) {
    try {
        const response = await fetch('/api/clientes/cadastrar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nome: nome,
                email: email,
                telefone: telefone
            })
        });
        
        const data = await response.json();
        return data.success ? data.cliente_id : null;
    } catch (error) {
        console.error('Erro ao cadastrar cliente:', error);
        return null;
    }
}

async function finalizarPedidoNoBanco(clienteEmail, clienteNome, itens, metodoPagamento) {
    try {
        
        const itensParaBanco = itens.map(item => ({
            produto_id: obterIdProduto(item.name), // Você precisa mapear nomes para IDs
            nome: item.name,
            preco: item.price,
            quantidade: item.quantity,
            imagem: item.image
        }));

        const response = await fetch('/api/pedidos/criar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                cliente_email: clienteEmail,
                cliente_nome: clienteNome,
                itens: itensParaBanco,
                metodo_pagamento: metodoPagamento
            })
        });
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Erro ao finalizar pedido:', error);
        return { success: false, message: 'Erro de conexão' };
    }
}


function obterIdProduto(nomeProduto) {
    const mapeamento = {
        'Stratocaster Classic': 1,
        'Les Paul Standard': 2,
        'Telecaster Vintage': 3,
        'SG Special': 4,
        'Acústica Dreadnought': 5,
        'Classical Pro': 6
    };
    return mapeamento[nomeProduto] || 1;
}


async function processPayment() {
    if (!selectedPayment) {
        alert('Por favor, selecione um método de pagamento!');
        return;
    }
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const confirmBtn = document.getElementById('confirm-payment');
    
    confirmBtn.innerHTML = '<i data-lucide="loader" class="w-5 h-5 animate-spin"></i> Processando...';
    confirmBtn.disabled = true;
    
    try {
        
        const clienteEmail = 'cliente@email.com'; 
        const clienteNome = 'Cliente GuitarShop'; 
        
        const resultado = await finalizarPedidoNoBanco(
            clienteEmail, 
            clienteNome, 
            cart, 
            selectedPayment
        );
        
        if (resultado.success) {
            alert(`🎉 Pedido #${resultado.numero_pedido} realizado com sucesso!\nMétodo: ${selectedPayment.toUpperCase()}\nTotal: R$ ${total.toLocaleString('pt-BR')}\n\nObrigado pela compra!`);
            
            
            cart = [];
            updateCartUI();
            closeCheckout();
        } else {
            alert(`❌ Erro no pedido: ${resultado.message}`);
        }
        
    } catch (error) {
        alert('❌ Erro ao processar pagamento. Tente novamente.');
    }
    
    
    confirmBtn.innerHTML = '<i data-lucide="lock" class="w-5 h-5"></i> Confirmar Pagamento';
    confirmBtn.disabled = true;
    confirmBtn.classList.add('opacity-50', 'cursor-not-allowed');
}