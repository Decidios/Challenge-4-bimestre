from flask import Flask, request, jsonify, send_from_directory
import database_ecommerce as db
import os
import json

app = Flask(__name__)

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_static(path):
    if path == "":
        return send_from_directory('.', 'index.html')
    else:
        return send_from_directory('.', path)


@app.route('/api/produtos', methods=['GET'])
def api_produtos():
    """Retorna todos os produtos"""
    produtos = db.listar_produtos()
    return jsonify([{
        'id': p[0],
        'nome': p[1],
        'tipo': p[2],
        'descricao': p[3],
        'preco': p[4],
        'imagem_url': p[5],
        'estoque': p[6]
    } for p in produtos])

@app.route('/api/clientes/cadastrar', methods=['POST'])
def api_cadastrar_cliente():
    """Cadastra um novo cliente"""
    data = request.get_json()
    
    cliente_id = db.cadastrar_cliente(
        nome=data.get('nome'),
        email=data.get('email'),
        telefone=data.get('telefone'),
        data_nascimento=data.get('data_nascimento')
    )
    
    if cliente_id:
        return jsonify({'success': True, 'cliente_id': cliente_id})
    else:
        return jsonify({'success': False, 'message': 'Erro ao cadastrar cliente'})

@app.route('/api/pedidos/criar', methods=['POST'])
def api_criar_pedido():
    """Cria um novo pedido"""
    try:
        data = request.get_json()
        print(f"🎯 Criando pedido para: {data.get('cliente_email')}")
        
        cliente = db.buscar_cliente_por_email(data.get('cliente_email'))
        if not cliente:
            cliente_id = db.cadastrar_cliente(
                nome=data.get('cliente_nome'),
                email=data.get('cliente_email')
            )
            if not cliente_id:
                return jsonify({'success': False, 'message': 'Erro ao cadastrar cliente'})
        else:
            cliente_id = cliente[0]
        
        resultado = db.criar_pedido(
            cliente_id=cliente_id,
            itens=data.get('itens', []),
            metodo_pagamento=data.get('metodo_pagamento')
        )
        
        if resultado:
            return jsonify({
                'success': True,
                'pedido_id': resultado['pedido_id'],
                'numero_pedido': resultado['numero_pedido'],
                'total': resultado['total']
            })
        else:
            return jsonify({'success': False, 'message': 'Erro ao criar pedido'})
            
    except Exception as e:
        print(f"❌ Erro na API: {e}")
        return jsonify({'success': False, 'message': 'Erro interno do servidor'})

@app.route('/api/pedidos/cliente/<email>', methods=['GET'])
def api_pedidos_cliente(email):
    """Retorna pedidos de um cliente"""
    pedidos = db.listar_pedidos_cliente(email)
    return jsonify([{
        'numero_pedido': p[0],
        'data_pedido': p[1],
        'status': p[2],
        'total': p[3],
        'metodo_pagamento': p[4]
    } for p in pedidos])

@app.route('/api/estatisticas', methods=['GET'])
def api_estatisticas():
    """Retorna estatísticas de vendas"""
    stats = db.obter_estatisticas_vendas()
    return jsonify(stats)

@app.route('/api/vendas/diarias', methods=['GET'])
def api_vendas_diarias():
    """Retorna vendas dos últimos dias"""
    dias = request.args.get('dias', 7, type=int)
    vendas = db.obter_vendas_por_dia(dias)
    return jsonify([{
        'data': v[0],
        'total_vendas': v[1],
        'quantidade_pedidos': v[2]
    } for v in vendas])

if __name__ == '__main__':
    if not os.path.exists('guitarshop.db'):
        print("🔄 Criando banco de dados...")
        db.criar_banco_ecommerce()
    
    print("🚀 E-commerce GuitarShop iniciando...")
    print("🌐 Acesse: http://localhost:5000")
    print("🎸 API REST disponível em: http://localhost:5000/api/")
    app.run(debug=True, port=5000)