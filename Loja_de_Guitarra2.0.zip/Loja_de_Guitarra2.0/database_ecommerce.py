import sqlite3
import os
from datetime import datetime

def criar_banco_ecommerce():
    """Cria todas as tabelas do sistema de e-commerce"""
    try:
        conn = sqlite3.connect('guitarshop.db')
        cursor = conn.cursor()
        
        # Tabela de Produtos
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            tipo TEXT NOT NULL,
            descricao TEXT,
            preco REAL NOT NULL,
            imagem_url TEXT,
            estoque INTEGER DEFAULT 0,
            ativo BOOLEAN DEFAULT 1,
            data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Tabela de Clientes
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            telefone TEXT,
            data_nascimento DATE,
            data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            categoria TEXT DEFAULT 'Normal'
        )
        ''')
        
        # Tabela de Pedidos
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER,
            numero_pedido TEXT UNIQUE,
            status TEXT DEFAULT 'Pendente',
            subtotal REAL NOT NULL,
            frete REAL DEFAULT 0,
            total REAL NOT NULL,
            metodo_pagamento TEXT,
            data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (cliente_id) REFERENCES clientes (id)
        )
        ''')
        
        # Tabela de Itens do Pedido
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS pedido_itens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pedido_id INTEGER,
            produto_id INTEGER,
            quantidade INTEGER NOT NULL,
            preco_unitario REAL NOT NULL,
            total_item REAL NOT NULL,
            FOREIGN KEY (pedido_id) REFERENCES pedidos (id),
            FOREIGN KEY (produto_id) REFERENCES produtos (id)
        )
        ''')
        
        # Tabela de Vendas (Resumo Diário)
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS vendas_diarias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data DATE UNIQUE,
            total_vendas REAL DEFAULT 0,
            quantidade_pedidos INTEGER DEFAULT 0,
            ticket_medio REAL DEFAULT 0
        )
        ''')
        
        # Inserir produtos de exemplo
        produtos_exemplo = [
            ('Stratocaster Classic', 'Elétrica', 'Guitarra elétrica clássica com som versátil', 4500.00, 
             'https://images.unsplash.com/photo-1558098329-a11cff621064?w=500&h=300&fit=crop&crop=center', 10),
            ('Les Paul Standard', 'Elétrica', 'Som encorpado ideal para rock', 6800.00,
             'https://images.unsplash.com/photo-1564186763535-ebb21c52731d?w=500&h=300&fit=crop&crop=center', 5),
            ('Telecaster Vintage', 'Elétrica', 'Timbre brilhante e definido', 5200.00,
             'https://images.unsplash.com/photo-1606112219348-204da240c7c4?w=500&h=300&fit=crop&crop=center', 8),
            ('SG Special', 'Elétrica', 'Leve e poderosa para rock pesado', 3900.00,
             'https://images.unsplash.com/photo-1570586437263-ab629fccc6c1?w=500&h=300&fit=crop&crop=center', 12),
            ('Acústica Dreadnought', 'Acústica', 'Som rico e projeção potente', 2800.00,
             'https://images.unsplash.com/photo-1525202015756-1ba56c98288b?w=500&h=300&fit=crop&crop=center', 15),
            ('Classical Pro', 'Clássica', 'Cordas de nylon para som suave', 3200.00,
             'https://images.unsplash.com/photo-1598488031602-e3c5cb0b5ba2?w=500&h=300&fit=crop&crop=center', 7)
        ]
        
        cursor.executemany('''
        INSERT OR IGNORE INTO produtos (nome, tipo, descricao, preco, imagem_url, estoque)
        VALUES (?, ?, ?, ?, ?, ?)
        ''', produtos_exemplo)
        
        conn.commit()
        conn.close()
        print("✅ Banco de dados 'guitarshop.db' criado com sucesso!")
        print("📦 Produtos cadastrados: 6 guitarras")
        return True
        
    except Exception as e:
        print(f"❌ Erro ao criar banco: {e}")
        return False

# Funções para Produtos
def listar_produtos():
    """Lista todos os produtos ativos"""
    try:
        conn = sqlite3.connect('guitarshop.db')
        cursor = conn.cursor()
        
        cursor.execute('''
        SELECT id, nome, tipo, descricao, preco, imagem_url, estoque 
        FROM produtos 
        WHERE ativo = 1 
        ORDER BY nome
        ''')
        
        produtos = cursor.fetchall()
        conn.close()
        return produtos
        
    except Exception as e:
        print(f"❌ Erro ao listar produtos: {e}")
        return []

def buscar_produto_por_nome(nome):
    """Busca produto pelo nome"""
    try:
        conn = sqlite3.connect('guitarshop.db')
        cursor = conn.cursor()
        
        cursor.execute('''
        SELECT * FROM produtos 
        WHERE nome LIKE ? AND ativo = 1
        ''', (f'%{nome}%',))
        
        produto = cursor.fetchone()
        conn.close()
        return produto
        
    except Exception as e:
        print(f"❌ Erro ao buscar produto: {e}")
        return None

# Funções para Clientes
def cadastrar_cliente(nome, email, telefone=None, data_nascimento=None):
    """Cadastra um novo cliente"""
    try:
        conn = sqlite3.connect('guitarshop.db')
        cursor = conn.cursor()
        
        cursor.execute('''
        INSERT INTO clientes (nome, email, telefone, data_nascimento)
        VALUES (?, ?, ?, ?)
        ''', (nome, email, telefone, data_nascimento))
        
        conn.commit()
        cliente_id = cursor.lastrowid
        conn.close()
        
        print(f"✅ Cliente {nome} cadastrado com ID: {cliente_id}")
        return cliente_id
        
    except sqlite3.IntegrityError:
        print("⚠️ Cliente já existe com este email")
        return None
    except Exception as e:
        print(f"❌ Erro ao cadastrar cliente: {e}")
        return None

def buscar_cliente_por_email(email):
    """Busca cliente pelo email"""
    try:
        conn = sqlite3.connect('guitarshop.db')
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM clientes WHERE email = ?', (email,))
        cliente = cursor.fetchone()
        conn.close()
        return cliente
        
    except Exception as e:
        print(f"❌ Erro ao buscar cliente: {e}")
        return None

# Funções para Pedidos
def criar_pedido(cliente_id, itens, metodo_pagamento):
    """Cria um novo pedido com itens"""
    try:
        conn = sqlite3.connect('guitarshop.db')
        cursor = conn.cursor()
        
        # Calcular totais
        subtotal = sum(item['preco'] * item['quantidade'] for item in itens)
        total = subtotal  # Frete grátis
        
        # Gerar número do pedido
        numero_pedido = f"GS{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # Criar pedido
        cursor.execute('''
        INSERT INTO pedidos (cliente_id, numero_pedido, subtotal, total, metodo_pagamento)
        VALUES (?, ?, ?, ?, ?)
        ''', (cliente_id, numero_pedido, subtotal, total, metodo_pagamento))
        
        pedido_id = cursor.lastrowid
        
        # Adicionar itens do pedido
        for item in itens:
            cursor.execute('''
            INSERT INTO pedido_itens (pedido_id, produto_id, quantidade, preco_unitario, total_item)
            VALUES (?, ?, ?, ?, ?)
            ''', (pedido_id, item['produto_id'], item['quantidade'], item['preco'], item['preco'] * item['quantidade']))
            
            # Atualizar estoque
            cursor.execute('''
            UPDATE produtos SET estoque = estoque - ? WHERE id = ?
            ''', (item['quantidade'], item['produto_id']))
        
        # Atualizar vendas diárias
        data_hoje = datetime.now().strftime('%Y-%m-%d')
        cursor.execute('''
        INSERT OR REPLACE INTO vendas_diarias (data, total_vendas, quantidade_pedidos, ticket_medio)
        VALUES (?, 
                COALESCE((SELECT total_vendas FROM vendas_diarias WHERE data = ?), 0) + ?,
                COALESCE((SELECT quantidade_pedidos FROM vendas_diarias WHERE data = ?), 0) + 1,
                (COALESCE((SELECT total_vendas FROM vendas_diarias WHERE data = ?), 0) + ?) / 
                (COALESCE((SELECT quantidade_pedidos FROM vendas_diarias WHERE data = ?), 0) + 1)
               )
        ''', (data_hoje, data_hoje, total, data_hoje, data_hoje, total, data_hoje))
        
        conn.commit()
        conn.close()
        
        print(f"✅ Pedido {numero_pedido} criado com sucesso!")
        print(f"💰 Total: R$ {total:.2f}")
        print(f"📦 Itens: {len(itens)} produtos")
        
        return {'pedido_id': pedido_id, 'numero_pedido': numero_pedido, 'total': total}
        
    except Exception as e:
        print(f"❌ Erro ao criar pedido: {e}")
        return None

def listar_pedidos_cliente(email):
    """Lista todos os pedidos de um cliente"""
    try:
        conn = sqlite3.connect('guitarshop.db')
        cursor = conn.cursor()
        
        cursor.execute('''
        SELECT p.numero_pedido, p.data_pedido, p.status, p.total, p.metodo_pagamento
        FROM pedidos p
        JOIN clientes c ON p.cliente_id = c.id
        WHERE c.email = ?
        ORDER BY p.data_pedido DESC
        ''', (email,))
        
        pedidos = cursor.fetchall()
        conn.close()
        return pedidos
        
    except Exception as e:
        print(f"❌ Erro ao listar pedidos: {e}")
        return []

# Funções para Relatórios
def obter_estatisticas_vendas():
    """Obtém estatísticas de vendas"""
    try:
        conn = sqlite3.connect('guitarshop.db')
        cursor = conn.cursor()
        
        # Total de vendas
        cursor.execute('SELECT SUM(total) FROM pedidos WHERE status != "Cancelado"')
        total_vendas = cursor.fetchone()[0] or 0
        
        # Total de pedidos
        cursor.execute('SELECT COUNT(*) FROM pedidos WHERE status != "Cancelado"')
        total_pedidos = cursor.fetchone()[0] or 0
        
        # Ticket médio
        ticket_medio = total_vendas / total_pedidos if total_pedidos > 0 else 0
        
        # Produto mais vendido
        cursor.execute('''
        SELECT pr.nome, SUM(pi.quantidade) as total_vendido
        FROM pedido_itens pi
        JOIN produtos pr ON pi.produto_id = pr.id
        JOIN pedidos p ON pi.pedido_id = p.id
        WHERE p.status != "Cancelado"
        GROUP BY pr.nome
        ORDER BY total_vendido DESC
        LIMIT 1
        ''')
        produto_mais_vendido = cursor.fetchone()
        
        conn.close()
        
        return {
            'total_vendas': total_vendas,
            'total_pedidos': total_pedidos,
            'ticket_medio': ticket_medio,
            'produto_mais_vendido': produto_mais_vendido
        }
        
    except Exception as e:
        print(f"❌ Erro ao obter estatísticas: {e}")
        return {}

def obter_vendas_por_dia(dias=7):
    """Obtém vendas dos últimos dias"""
    try:
        conn = sqlite3.connect('guitarshop.db')
        cursor = conn.cursor()
        
        cursor.execute('''
        SELECT data, total_vendas, quantidade_pedidos 
        FROM vendas_diarias 
        ORDER BY data DESC 
        LIMIT ?
        ''', (dias,))
        
        vendas = cursor.fetchall()
        conn.close()
        return vendas
        
    except Exception as e:
        print(f"❌ Erro ao obter vendas por dia: {e}")
        return []

# Teste do banco
if __name__ == "__main__":
    print("🎸 Iniciando banco de dados GuitarShop...")
    
    if criar_banco_ecommerce():
        print("\n📊 Estatísticas do sistema:")
        produtos = listar_produtos()
        print(f"   🎸 Produtos cadastrados: {len(produtos)}")
        
        # Testar funções
        stats = obter_estatisticas_vendas()
        print(f"   💰 Total de vendas: R$ {stats.get('total_vendas', 0):.2f}")
        print(f"   📦 Total de pedidos: {stats.get('total_pedidos', 0)}")
        
        print("\n🚀 Banco pronto para uso!")
    else:
        print("😥 Erro ao criar o banco de dados")